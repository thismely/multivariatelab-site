(function(){document.addEventListener('DOMContentLoaded',async()=>{
 const root=document.getElementById('mlab-resource-links');if(!root)return;const {el,link,load,failure}=window.MLab;
 try{const data=await load(root);root.replaceChildren();data.forEach(x=>{const b=el('article','mlab-card');b.append(el('span','mlab-eyebrow',x.chapter),el('strong','',x.method),el('small','',x.status));const items=[['学习知识',x.knowledge],['下载Notebook',x.notebook],['业务案例',x.case]];items.forEach(([name,path])=>{if(path){const a=el('a','',name);a.href=link(path);b.append(a);}else b.append(el('small','',name+'：建设中'));});if(x.teacher_demo){const a=el('a','','教师真实数据示范（本机复现）');a.href=link(x.teacher_demo);b.append(a);}root.append(b);});}catch(e){failure(root,e)}
});})();
