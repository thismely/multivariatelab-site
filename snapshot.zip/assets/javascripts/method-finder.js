(function(){document.addEventListener('DOMContentLoaded',async()=>{
 const root=document.getElementById('mlab-method-finder');if(!root)return;
 const {el,link,load,failure}=window.MLab;
 try{
  const data=await load(root);const fields=['goal','input','target'].map(x=>root.querySelector(`[data-field="${x}"]`));
  function render(){const [goal,input,target]=fields.map(x=>x.value);const results=data.filter(m=>m.goals.includes(goal)&&m.inputs.includes(input)&&m.targets.includes(target));const list=root.querySelector('[data-results]');list.replaceChildren();
   if(!results.length){root.querySelector('[data-status]').textContent='这一组合没有预设的直接建议；请检查目标与变量类型，并参照全部章节或向教师讨论。';return;}
   root.querySelector('[data-status]').textContent=`匹配 ${results.length} 种课程方法；推荐属于教学规则提示，不是统计模型适用性的最终判定。`;
   results.forEach(m=>{let box=el('article','mlab-card');box.append(el('span','mlab-eyebrow',m.chapter),el('strong','',m.name),el('p','',m.question),el('small','',`前提：${m.conditions}`),el('small','',`局限：${m.limitations}`));let a=el('a','','查看章节知识');a.href=link(m.page);box.append(a);list.append(box);});
  }
  fields.forEach(f=>f.addEventListener('change',render));render();
 }catch(e){failure(root,e)}
});})();
