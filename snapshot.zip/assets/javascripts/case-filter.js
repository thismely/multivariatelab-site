(function(){document.addEventListener('DOMContentLoaded',async()=>{
 const root=document.getElementById('mlab-case-library');if(!root)return;
 const {el,link,load,failure}=window.MLab;
 try{const data=await load(root);const fields=['keyword','domain','chapter'].map(x=>root.querySelector(`[data-field="${x}"]`));
 function render(){const [keyword,domain,chapter]=fields.map(x=>x.value);const key=keyword.trim().toLocaleLowerCase();const matches=data.filter(c=>(domain==='all'||c.domain===domain)&&(chapter==='all'||c.chapter===chapter||(Array.isArray(c.chapters)&&c.chapters.includes(chapter)))&&(!key||(c.title+' '+c.id+' '+(c.chapters||[c.chapter]).join(' ')).toLocaleLowerCase().includes(key)));const list=root.querySelector('[data-results]');list.replaceChildren();root.querySelector('[data-status]').textContent=`显示 ${matches.length} / ${data.length} 个案例条目（建设中条目不可点击）。`;
 matches.forEach(c=>{const b=el('article','mlab-card');b.append(el('span','mlab-eyebrow',c.id+' · '+c.domain),el('strong','',c.title),el('small','',(c.chapters||[c.chapter]).join(' / ')+' · '+c.source));const pill=el('span','mlab-pill'+(c.status==='建设中'?' mlab-pill--pending':''),c.status);b.append(pill);if(c.status==='已发布'&&c.page){const a=el('a','','阅读案例');a.href=link(c.page);b.append(a);}list.append(b);});
 if(!matches.length)list.append(el('p','mlab-note','没有匹配案例，请调整筛选条件。'));
 }
 fields.forEach(f=>f.addEventListener(f.tagName==='INPUT'?'input':'change',render));render();
 }catch(e){failure(root,e)}
});})();
