(function(){document.addEventListener('DOMContentLoaded',async()=>{
 const root=document.getElementById('mlab-lab-center');if(!root)return;const {el,link,load,failure}=window.MLab;
 try{const data=await load(root);const select=root.querySelector('[data-field="chapter"]');
 function render(){const list=root.querySelector('[data-results]');list.replaceChildren();const rows=data.filter(x=>select.value==='all'||select.value===x.chapter||(Array.isArray(x.chapters)&&x.chapters.includes(select.value)));root.querySelector('[data-status]').textContent=`当前列出 ${rows.length} 个实验。`;rows.forEach(x=>{const b=el('article','mlab-card');b.append(el('span','mlab-eyebrow',x.id+' · '+(x.chapters||[x.chapter]).join(' / ')+' · '+x.level),el('strong','',x.title),el('small','',x.summary),el('small','',x.requirements),el('span','mlab-pill',x.status));if(x.status==='已发布'&&x.file){let a=el('a','','下载Notebook');a.href=link(x.file);a.download='';b.append(a)}list.append(b);});}
 select.addEventListener('change',render);render();}catch(e){failure(root,e)}
});})();
