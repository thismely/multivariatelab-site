(function () {
  function initialize() {
    const root = document.getElementById('mlab-my-task');
    if (!root || root.dataset.ready) return;
    root.dataset.ready = '1';
    const form = root.querySelector('[data-assignment-form]');
    const input = form.querySelector('input');
    const submit = root.querySelector('[data-find-task]');
    const reset = root.querySelector('[data-reset-task]');
    const status = root.querySelector('[data-assignment-status]');
    const result = root.querySelector('[data-assignment-result]');
    let payload = null;
    const el = window.MLab.el;
    const site = window.MLab.link;
    function link(text, path) {
      const node = el('a', null, text);
      node.href = path;
      return node;
    }
    function list(items, code) {
      const ul = el('ul');
      items.forEach(item => {
        const li = el('li');
        li.append(code ? el('code', null, item) : document.createTextNode(item));
        ul.append(li);
      });
      return ul;
    }
    function section(parent, title, items, code) {
      parent.append(el('h3', null, title), list(items, code));
    }
    function dependencyLinks(ids) {
      const p = el('p', 'mlab-note');
      if (!ids.length) { p.textContent = '无额外依赖。'; return p; }
      ids.forEach((id, index) => {
        if (index) p.append(document.createTextNode(' · '));
        p.append(link(id + ' 原任务要求', site('coursework/tasks/#' + id)));
      });
      return p;
    }
    function show(task) {
      result.replaceChildren();
      result.hidden = false;
      const title = el('h2', null, task.task_id + ' · ' + task.title);
      title.tabIndex = -1;
      result.append(title);
      const account = el('p');
      account.append(document.createTextNode('本人Gitee账号：'), el('code', null, task.account),
        document.createTextNode(' · 唯一主责，无共同作者。'));
      result.append(account, el('p', 'mlab-note', task.module_name + ' · ' + task.level +
        ' · 本轮首批派发日 ' + payload.assigned_on + ' · 核对日 ' + payload.verified_on));
      result.append(el('p', 'mlab-assignment-rule',
        '已指派，待本人接单和交付。互审尚未安排：个人完整交付与自检完成后，由教师另行指定非作者。'));
      result.append(el('p', null, task.objective));
      const issue = link('打开本人原Issue，确认接单', task.issue_url);
      issue.className = 'mlab-task-primary';
      result.append(issue, el('p', 'mlab-note',
        '需要使用本人Gitee账号登录，并已加入校园课程仓库；不要另建同名Issue或自行改派。'));
      section(result, '我的完整交付要求', task.requirements);
      section(result, '原任务最低验收条件', task.criteria);
      result.append(el('h3', null, '本人任务的具体实践作业（2026-10-28补充）'));
      const practice = link(task.task_id + ' · 打开案例题、数据路径、研究步骤与验收要求',
        site('coursework/practice/' + task.task_id + '/'));
      practice.className = 'mlab-task-primary';
      result.append(practice, el('p', null,
        '在原建设交付之外，还需提交本人研究代码、实际生成的结果表图和案例报告。新增允许范围为 cases/practice/' +
        task.task_id + '/。起步Notebook只检查数据，不是完成答案；数据和研究结果留在校园Gitee，不复制到公开网站。'));
      result.append(el('p', 'mlab-note',
        '另需满足来源与文件有效、专业正确、可复现、本人贡献和后续独立互审证据。教师现有示范不计为本人交付。'));
      section(result, '允许修改的文件范围', task.files, true);
      result.append(el('p', 'mlab-note',
        '这些是本人应建设或完善的源文件，不是已经发布的下载链接。不要只交其中一部分；涉及其他文件先请教师明确。'));
      result.append(el('h3', null, '依赖与当前阶段'));
      result.append(el('h4', null, '开始依赖'), dependencyLinks(task.dependencies));
      result.append(el('h4', null, '最终集成依赖'), dependencyLinks(task.integration_dependencies));
      result.append(el('p', null,
        '上游未具备时先完成自己的方法阅读、手算、数据与输入输出字典、接口理解及方案。方案如实标未运行；专业实现与集成按教师确认的依赖顺序进行。'));
      result.append(el('h3', null, '我的个人分支'));
      const branch = el('p');
      const branchCode = el('code', 'mlab-branch-name', task.branch);
      const copy = el('button', 'mlab-copy-branch', '复制分支名');
      copy.type = 'button';
      copy.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(task.branch);
          status.textContent = '已复制分支名。请在VS Code从最新main创建该个人分支。';
        } catch (_) {
          status.textContent = '浏览器暂不能自动复制。请选中上方完整分支名手动复制。';
        }
      });
      branch.append(branchCode, copy);
      result.append(branch);
      result.append(el('p', 'mlab-note',
        '从最新main建立此分支，提交个人PR；学生不能直接推送或合并main。保存、提交、推送、PR是不同步骤。'));
      const steps = [
        ['step-1', '确认接单：找到原Issue，复述目标、范围、依赖和困难'],
        ['step-2', '准备Windows环境：检查Git、Python、VS Code和网络'],
        ['step-3', '克隆校园仓库：使用本人账号和图形化菜单'],
        ['step-4', '创建个人分支：核对分支名，保留当前修改'],
        ['step-5', '完成全部交付：知识、实验、案例或页面依原任务要求'],
        ['step-6', '本人自检：实际运行、边界条件和无输出源码'],
        ['step-7', '提交与推送：逐文件看差异，案例结果只交Gitee，勿传凭据'],
        ['step-8', '创建PR：目标main，关联原Issue并申请教师安排互审'],
        ['step-9', '教师指定互审后：回应、修订、复核与最终验收']
      ];
      const ol = el('ol');
      steps.forEach(([id, text]) => {
        const li = el('li');
        li.append(link(text, site('coursework/single-task-guide/#' + id)));
        ol.append(li);
      });
      result.append(el('h3', null, '一步一步做'), ol);
      result.append(el('p', 'mlab-note',
        '本页是派发快照，不自动判断接单、进度或完成。课堂日期和截止日由教师通知；最新变更以原Issue为准。'));
      status.textContent = '已找到 ' + task.account + ' 的唯一主责任务 ' + task.task_id + '。';
      title.focus();
    }
    form.addEventListener('submit', event => {
      event.preventDefault();
      result.hidden = true;
      result.replaceChildren();
      if (!payload) return;
      const query = input.value.trim().replace(/^@/, '').toLowerCase();
      if (!/^[a-z0-9][a-z0-9_.-]{0,99}$/.test(query) || query.includes('..')) {
        status.textContent = '请输入Gitee账号，不填姓名、昵称、邮箱、密码或整段网址。';
        input.focus();
        return;
      }
      const task = payload.assignments.find(item => item.account.toLowerCase() === query);
      if (task) show(task);
      else {
        status.textContent = '未找到该账号的本轮派发记录。请核对Gitee个人空间地址最后一段；仍无记录请教师核对，不自行认领任务。';
        input.focus();
      }
    });
    reset.addEventListener('click', () => {
      input.value = '';
      result.replaceChildren();
      result.hidden = true;
      status.textContent = payload ? '请输入Gitee账号查询本人的一项任务。' : '派发记录尚未加载。';
      input.focus();
    });
    window.MLab.load(root).then(data => {
      if (data.assignment_mode !== 'individual' ||
          data.review_policy !== 'teacher_after_author_delivery' ||
          !Array.isArray(data.assignments) || data.assignments.length < 1 || data.assignments.length > 70 ||
          new Set(data.assignments.map(x => x.account.toLowerCase())).size !== data.assignments.length ||
          new Set(data.assignments.map(x => x.task_id)).size !== data.assignments.length) {
        throw new Error('派发记录格式与当前单人任务规则不符');
      }
      payload = data;
      submit.disabled = false;
      status.textContent = data.assignments.length + '项单人任务记录已加载（核对日 ' + data.verified_on + '）。请输入Gitee账号查询。';
    }).catch(() => {
      submit.disabled = true;
      status.textContent = '派发记录暂时无法读取。请刷新重试，或通过下方70项原任务入口和教师在Gitee的记录核对；不要自行认领。';
    });
  }
  document.addEventListener('DOMContentLoaded', initialize);
  if (typeof document$ !== 'undefined') document$.subscribe(initialize);
  if (document.readyState !== 'loading') initialize();
})();

