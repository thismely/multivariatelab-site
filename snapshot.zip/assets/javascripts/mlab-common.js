(function(){
  function el(tag,cls,text){ const n=document.createElement(tag); if(cls)n.className=cls; if(text!==undefined)n.textContent=String(text); return n; }
  function link(path){ return new URL('../../'+path,document.baseURI).href; }
  async function load(node){ const res=await fetch(new URL(node.dataset.src,document.baseURI)); if(!res.ok)throw Error('无法读取资源清单');return await res.json(); }
  function failure(node,e){const s=node.querySelector('[data-status]');if(s)s.textContent='加载失败：'+e.message+'。可查看章节目录。';}
  window.MLab={el,link,load,failure};
})();
