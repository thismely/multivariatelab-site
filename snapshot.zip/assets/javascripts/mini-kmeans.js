(function(){document.addEventListener('DOMContentLoaded',()=>{
 const root=document.getElementById('mlab-kmeans');if(!root)return;
 const points=[[1.0,1.0],[1.5,1.4],[0.7,1.8],[1.8,0.7],[5.0,5.0],[5.7,5.3],[4.8,5.9],[5.8,4.6],[8.4,1.3],[9.3,1.0],[8.8,2.2],[9.7,1.8]];
 const palette=['#168199','#c06d2f','#7869b5','#3a9b65'];const choose=root.querySelector('[data-field="k"]');
 function squared(a,b){return (a[0]-b[0])**2+(a[1]-b[1])**2}
 function run(k){let centers=[points[0].slice()];for(let i=1;i<k;i++){let best=points[0],dist=-1;for(let p of points){let d=Math.min(...centers.map(c=>squared(p,c)));if(d>dist+1e-10){dist=d;best=p;}}centers.push(best.slice());}
 let labels=Array(points.length).fill(-1),iterations=0;
 for(let n=0;n<30;n++){iterations++;let next=points.map(p=>centers.map(c=>squared(p,c)).indexOf(Math.min(...centers.map(c=>squared(p,c)))));let sums=centers.map(()=>[0,0]),counts=centers.map(()=>0);for(let j=0;j<points.length;j++){let a=next[j];sums[a][0]+=points[j][0];sums[a][1]+=points[j][1];counts[a]++;}
 const newCenters=centers.map((c,j)=>counts[j]?[sums[j][0]/counts[j],sums[j][1]/counts[j]]:c.slice());const stable=next.every((x,j)=>x===labels[j])&&newCenters.every((c,j)=>squared(c,centers[j])<1e-12);labels=next;centers=newCenters;if(stable)break;}
 return {centers,labels,iterations};}
 function makeSvg(k){const out=run(k),NS='http://www.w3.org/2000/svg';const svg=document.createElementNS(NS,'svg');svg.setAttribute('viewBox','0 0 640 335');svg.setAttribute('role','img');svg.setAttribute('aria-label',`二维K-Means示例，${k}个簇`);
 function shape(tag,props){let e=document.createElementNS(NS,tag);for(let [a,b] of Object.entries(props))e.setAttribute(a,String(b));svg.append(e);return e}
 const px=p=>40+p[0]*56,py=p=>315-p[1]*47;
 [1,3,5].forEach(v=>{shape('line',{x1:36,y1:py([0,v]),x2:620,y2:py([0,v]),stroke:'#d8dfe5','stroke-width':'1'});});
 points.forEach((p,i)=>{shape('circle',{cx:px(p),cy:py(p),r:9,fill:palette[out.labels[i]],stroke:'white','stroke-width':2});});
 out.centers.forEach((c,i)=>{shape('rect',{x:px(c)-8,y:py(c)-8,width:16,height:16,rx:2,fill:palette[i],stroke:'#102b3c','stroke-width':2});});
 root.querySelector('[data-chart]').replaceChildren(svg);root.querySelector('[data-status]').textContent=`模拟样本 ${points.length} 个，k=${k}，迭代 ${out.iterations} 次；彩色圆点代表样本，黑边方块代表簇中心。固定初始化，结果可复现。`;
 }
 root.querySelector('[data-run]').addEventListener('click',()=>makeSvg(Number(choose.value)));
 root.querySelector('[data-reset]').addEventListener('click',()=>{choose.value='3';makeSvg(3)});makeSvg(3);
});})();
