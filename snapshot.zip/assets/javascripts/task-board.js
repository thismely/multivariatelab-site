(function(){
  function initialize(){
    const root=document.getElementById('mlab-task-board');
    if(!root||root.dataset.ready)return;
    root.dataset.ready='1';
    const query=root.querySelector('[data-task-field="query"]');
    const module=root.querySelector('[data-task-field="module"]');
    const level=root.querySelector('[data-task-field="level"]');
    const rows=Array.from(root.querySelectorAll('[data-task-id]'));
    function render(){
      const text=query.value.trim().toLocaleLowerCase();let count=0;
      rows.forEach(row=>{
        const matched=/^t\d{3}$/.test(text)?row.dataset.taskId.toLocaleLowerCase()===text:row.textContent.toLocaleLowerCase().includes(text);
        const visible=(!text||matched)&&
          (module.value==='all'||row.dataset.taskModule===module.value)&&
          (level.value==='all'||row.dataset.taskLevel===level.value);
        row.hidden=!visible;if(visible)count++;
      });
      root.querySelector('[data-task-status]').textContent=`显示${count} / ${rows.length}项任务，正式分配由教师决定。`;
    }
    query.addEventListener('input',render);module.addEventListener('change',render);level.addEventListener('change',render);
    render();
  }
  document.addEventListener('DOMContentLoaded',initialize);
  if(typeof document$!=='undefined')document$.subscribe(initialize);
})();
